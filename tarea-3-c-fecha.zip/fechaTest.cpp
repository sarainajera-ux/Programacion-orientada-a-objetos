#include <iostream>
#include "main.cpp"
using namespace std;

int main()
{
    int dia,mes,anio;
    
    cout<<("ingrese un dia del mes en numero: ");
    cin>>dia;
    
    cout<<("ingrese un un mes del año en numero: ");
    cin>>mes;
    
    cout<<("ingrese un año en numero: ");
    cin>>anio;
    
    Fecha f1(dia, mes, anio);
    
    cout<<"la fecha es: "<<f1.mostrarfecha()<<endl;
    

    return 0;
}