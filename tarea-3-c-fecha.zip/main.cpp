/* PTOBLEMA 3 FECHA 
SARAI RODRIGUEZ NAJERA 
00616609
ING ENN TECNOOLOGIAS DE LA INFO*/

#include <iostream>
#include <string>
using namespace std;

class Fecha{
public:    
    int mes;
    int dia;
    int anio;
    
    Fecha(int d, int m, int a){
        mes=m;
        dia=d;
        anio=a;
    }
    string mostrarfecha(){
        return to_string(dia) + "/" + to_string(mes) + "/" + to_string(anio);
    }
};

