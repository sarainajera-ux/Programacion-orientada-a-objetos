/*SARAI RODRIGUEZ NAJERA
00616609
ING EN TECNOLOGIAS DE LA INFO*/}

public class Factura
{
    public string numeroPieza;
    public string descripcion;
    public int cantidad;
    public double precioPorArticulo;

    public Factura(string numeroPieza, string descripcion, int cantidad, double precioPorArticulo)
    {
        this.numeroPieza = numeroPieza;
        this.descripcion = descripcion;
        this.cantidad = cantidad > 0 ? cantidad : 0;
        this.precioPorArticulo = precioPorArticulo > 0 ? precioPorArticulo : 0.0;
    }

    public double ObtenerMontoFactura()
    {
        return cantidad * precioPorArticulo;
    }
}