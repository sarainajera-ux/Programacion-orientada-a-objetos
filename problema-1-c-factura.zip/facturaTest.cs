using System;

public class FacturaTest
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Número de pieza:");
        string num = Console.ReadLine();

        Console.WriteLine("Descripción:");
        string desc = Console.ReadLine();

        Console.WriteLine("Cantidad:");
        int cant = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Precio por artículo:");
        double precio = Convert.ToDouble(Console.ReadLine());

        Factura f1 = new Factura(num, desc, cant, precio);

        Console.WriteLine("Factura: " + f1.numeroPieza + " - " + f1.descripcion);
        Console.WriteLine("Monto total: " + f1.ObtenerMontoFactura());
    }
}

