/*SARAI RODRIGUEZ NAJERA
00616609
ING EN TECNOLOGIAS DE LA INFO*/

public class Empleado{
    
    public string nombre1;
    public string apellidoP;
    public double salario;

    public Empleado(string nombre1, string apellidoP, double salario)
    {
        this.nombre1 = nombre1;
        this.apellidoP = apellidoP;
        if (salario > 0)
        {
            this.salario = salario;
        }
        else
        {
            this.salario = 0.0;
        }
    }

    public double obtenersalarioanual()
    {
        return salario * 12;
    }

    public void aplicaraumento()
    {
        salario = salario * 1.10;
    }
}
