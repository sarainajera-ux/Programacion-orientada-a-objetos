using System;

public class EmpleadoTest
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Ingresa nombre del primer empleado:");
        string nombre1 = Console.ReadLine();
        
        Console.WriteLine("Ingresa apellido paterno del primer empleado:");
        string apellidoP1 = Console.ReadLine();
        
        Console.WriteLine("Ingresa salario del primer empleado:");
        double salario1 = Convert.ToDouble(Console.ReadLine());
        
        Empleado emp1 = new Empleado(nombre1, apellidoP1, salario1);
        
        Console.WriteLine("Ingresa nombre del segundo empleado:");
        string nombre2 = Console.ReadLine();
        
        Console.WriteLine("Ingresa apellido paterno del segundo empleado:");
        string apellidoP2 = Console.ReadLine();
        
        Console.WriteLine("Ingresa salario del segundo empleado:");
        double salario2 = Convert.ToDouble(Console.ReadLine());
        
        Empleado emp2 = new Empleado(nombre2, apellidoP2, salario2);
        
        Console.WriteLine("Salario anual de " + emp1.nombre1 + " " + emp1.apellidoP + ": " + emp1.obtenersalarioanual());
        Console.WriteLine("Salario anual de " + emp2.nombre1 + " " + emp2.apellidoP + ": " + emp2.obtenersalarioanual());
        
        emp1.aplicaraumento();
        emp2.aplicaraumento();
        
        Console.WriteLine("Salario anual de " + emp1.nombre1 + " " + emp1.apellidoP + " depues del aumento: " + emp1.obtenersalarioanual());
        Console.WriteLine("Salario anual de " + emp2.nombre1 + " " + emp2.apellidoP + " depues del aumento: " + emp2.obtenersalarioanual());
    }
}
