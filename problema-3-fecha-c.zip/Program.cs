/* PTOBLEMA 3 FECHA 
SARAI RODRIGUEZ NAJERA 
00616609
ING ENN TECNOOLOGIAS DE LA INFO*/

using System;

public class Fecha{
    
    public int Dia { get; set; }
    public int Mes { get; set; }
    public int Anio { get; set; }

    public Fecha(int d, int m, int a)
    {
        Dia = d;
        Mes = m;
        Anio = a;
    }

    public string MostrarFecha()
    {
        return $"{Dia}/{Mes}/{Anio}";
    }
}
