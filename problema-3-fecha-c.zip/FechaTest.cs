using System;

public class FechaTest{
    public static void Main(string[] args)
    {
        Console.Write("Ingrese un día del mes en número: ");
        int dia = int.Parse(Console.ReadLine());
        
        Console.Write("Ingrese un mes del año en número: ");
        int mes = int.Parse(Console.ReadLine());
        
        Console.Write("Ingrese un año en número: ");
        int anio = int.Parse(Console.ReadLine());
        
        Fecha f1 = new Fecha(dia, mes, anio);
        
        Console.WriteLine("La fecha es: " + f1.MostrarFecha());
    }
}
