import java.util.Scanner;

public class fechaTest{
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.println("ingrese un dia del mes en numero: ");
        int dia = input.nextInt();
        input.nextLine();
        
        System.out.println("ingrese un mes del año en numero: ");
        int mes = input.nextInt();
        input.nextLine();
        
        System.out.println("ingrese un año en numero: ");
        int anio = input.nextInt();
        input.nextLine();
        
        Fecha f1 = new Fecha(dia,mes, anio);
        
        System.out.println("la fecha es:" + f1.mostrarfecha());
    }
    
}
