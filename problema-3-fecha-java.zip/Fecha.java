/* PTOBLEMA 3 FECHA 
SARAI RODRIGUEZ NAJERA 
00616609
ING ENN TECNOOLOGIAS DE LA INFO*/

public class Fecha{
    int mes;
    int dia;
    int anio;
    
    Fecha(int d, int m, int a){
        mes = m;
        dia = d;
        anio = a;
    }
    
    String mostrarfecha(){
        return dia + "/" + mes + "/" + anio;
    }
	
}
