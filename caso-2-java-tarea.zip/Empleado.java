/* PROBLEMA 2 EMPLEADO */
/*SARAI RODRIGUEZ NAJERA
00616609
ING EN TECNOLOGIAS DE LA INFO*/

public class Empleado{
    
    String nombre1;
    String apellidoP;
    double salario;
    
    Empleado(String nombre1, String apellidoP, double salario){
        this.nombre1 = nombre1;
        this.apellidoP = apellidoP;
        if(salario > 0){
            this.salario = salario;
        }else{
            this.salario=0.0;
        }
    }
	
	double obtenersalarioanual(){
	    return salario*12;
	}
	void aplicaraumento(){
        salario = salario * 1.10;
    }
}
