import java.util.Scanner;

public class EmpleadoTest {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Ingresa nombre del primer empleado:");
        String nombre1 = input.nextLine();

        System.out.println("Ingresa apellido paterno del primer empleado:");
        String apellidoP = input.nextLine();

        System.out.println("Ingresa salario del primer empleado:");
        double salario1 = input.nextDouble();
        input.nextLine(); 

        Empleado emp1 = new Empleado(nombre1, apellidoP, salario1);
        
        System.out.println("Ingresa nombre del segundo empleado:");
        String nombre2 = input.nextLine();

        System.out.println("Ingresa apellido paterno del segundo empleado:");
        String apellidoP2 = input.nextLine();

        System.out.println("Ingresa salario del segundo empleado:");
        double salario2 = input.nextDouble();

        Empleado emp2 = new Empleado(nombre2, apellidoP2, salario2);
        
        System.out.println("Salario anual de " + emp1.nombre1 + " " + emp1.apellidoP + ": " + emp1.obtenersalarioanual());
        System.out.println("Salario anual de " + emp2.nombre1 + " " + emp2.apellidoP + ": " + emp2.obtenersalarioanual());
        
        emp1.aplicaraumento();
        emp2.aplicaraumento();
        
        System.out.println("Salario anual de " + emp1.nombre1 + " " + emp1.apellidoP + " depues del aumento: " + emp1.obtenersalarioanual());
        System.out.println("Salario anual de " + emp2.nombre1 + " " + emp2.apellidoP + " despues del aumento: " + emp2.obtenersalarioanual());
    }
}
