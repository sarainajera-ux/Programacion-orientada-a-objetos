/*PROBLEMA 2 EMPLEADOS*/
/*SARAI RODRIGUEZ NAJERA
00616609
ING EN TECNOLOGIAS DE LA INFO*/

#include <iostream>
#include <string>
using namespace std;

class Empleado {
public:
    string nombre;
    string apellido;
    double salario;

    Empleado(string n, string ap, double s) {
        nombre = n;
        apellido = ap;
        salario = (s > 0) ? s : 0.0;
    }

    double obtenerSalarioAnual() {
        return salario * 12;
    }

    void aplicarAumento() {
        salario = salario * 1.10;
    }
};

int main() {
    string nombre, apellido;
    double salario;

    cout << "Ingresa nombre del primer empleado: ";
    cin >> nombre;
    cout << "Ingresa apellido paterno del primer empleado: ";
    cin >> apellido;
    cout << "Ingresa salario del primer empleado: ";
    cin >> salario;

    Empleado emp1(nombre, apellido, salario);

    cout << "Ingresa nombre del segundo empleado: ";
    cin >> nombre;
    cout << "Ingresa apellido paterno del segundo empleado: ";
    cin >> apellido;
    cout << "Ingresa salario del segundo empleado: ";
    cin >> salario;

    Empleado emp2(nombre, apellido, salario);

    cout << "Salario anual de " << emp1.nombre << " " << emp1.apellido << ": " << emp1.obtenerSalarioAnual() << endl;
    cout << "Salario anual de " << emp2.nombre << " " << emp2.apellido << ": " << emp2.obtenerSalarioAnual() << endl;

    emp1.aplicarAumento();
    emp2.aplicarAumento();

    cout << "Salario anual de " << emp1.nombre << " " << emp1.apellido << " después del aumento: " << emp1.obtenerSalarioAnual() << endl;
    cout << "Salario anual de " << emp2.nombre << " " << emp2.apellido << " después del aumento: " << emp2.obtenerSalarioAnual() << endl;

    return 0;
}
