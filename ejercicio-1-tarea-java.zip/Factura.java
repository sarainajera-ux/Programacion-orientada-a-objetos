/* PROBLEMA 1 FACTURA */
/*SARAI RODRIGUEZ NAJERA
00616609
ING EN TECNOLOGIAS DE LA INFO*/

public class Factura
{
    //variable instancia = atributo //caracteristica 
    String numpieza;
    String descripcion; 
    int cantidad;
    double precio;
    
    //constructor inicializa las 4 variables instancia 
    Factura(){
        numpieza = "";
        descripcion = "";  
        cantidad = 0;
        precio= 0.0;
    }
    
    double obtenermontofactura(){
        return cantidad*precio;
    }
    
}
