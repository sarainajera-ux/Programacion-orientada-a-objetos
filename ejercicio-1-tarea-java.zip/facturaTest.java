import java.util.Scanner;

public class facturaTest{
    public static void 2{
        Factura ferre = new Factura();
        Scanner input = new Scanner(System.in);
        
        System.out.println("ingresa numero de pieza");
        ferre.numpieza=input.nextLine();
        
         System.out.println("agrega la descripcion: ");
        ferre.descripcion=input.nextLine();
        
         System.out.println("cantidad: ");
        ferre.cantidad=input.nextInt();
        
         System.out.println("precio: ");
        ferre.precio=input.nextDouble();
        
        if (ferre.precio < 0) ferre.precio = 0.0;
        if (ferre.cantidad < 0) ferre.cantidad = 0;
        
        System.out.println("factura: "+ ferre.obtenermontofactura());
        
    }
}