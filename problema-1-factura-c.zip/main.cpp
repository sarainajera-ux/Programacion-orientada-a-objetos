/*SARAI RODRIGUEZ NAJERA 
00616609
ING EN TECNOLOGIAS DE LA INFORMACION */

#include <iostream>
#include <string>
using namespace std;

class Factura {
public:
    string numeroPieza;
    string descripcion;
    int cantidad;
    double precioPorArticulo;

    Factura(string num, string desc, int cant, double precio) {
        numeroPieza = num;
        descripcion = desc;
        cantidad = (cant > 0) ? cant : 0;
        precioPorArticulo = (precio > 0) ? precio : 0.0;
    }

    double obtenerMontoFactura() {
        return cantidad * precioPorArticulo;
    }
};

int main() {
    string num, desc;
    int cant;
    double precio;

    cout << "Número de pieza: ";
    cin >> num;

    cout << "Descripción: ";
    cin >> desc;

    cout << "Cantidad: ";
    cin >> cant;

    cout << "Precio por artículo: ";
    cin >> precio;

    Factura f1(num, desc, cant, precio);

    cout << "Factura: " << f1.numeroPieza << " - " << f1.descripcion << endl;
    cout << "Monto total: " << f1.obtenerMontoFactura() << endl;

    return 0;
}
